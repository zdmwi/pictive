import random
import os
import pprint
import fake_info

CALL = "CALL"
REGISTER = "register"
FRIEND = "addFriend"
PHOTOPOST = "makePhotoPost"
TEXTPOST = "makeTextPost"
COMMENT = "leaveComment"
MAXID = 500000

# create stored procedure calls
def register(fname, lname, password, email):
    return f"{CALL} {REGISTER}('{fname}', '{lname}', '{password}', '{email}');"

def friend(uid, fid, type):
    return f"{CALL} {FRIEND}({uid}, {fid}, '{type}');"

def post(uid, photo="", caption=""):
    if not photo:
        return f'{CALL} {TEXTPOST}({uid}, "{caption}");'
    return f'{CALL} {PHOTOPOST}({uid}, "{photo}", "{caption}");'

def comment(uid, pid, comment):
    return f'{CALL} {COMMENT}({uid}, {pid}, "{comment}");'


def getUsers(filename):
    f = open(filename, "r")
    records = f.readlines()
    f.close()
    return records

# utility
def randomids(blacklist, ubound, freq):
    nums = []
    r = 0
    # random.seed()
    random.randint(1,5)
    for i in range(freq):
        num = random.randint(1,ubound)
        while num in blacklist:
            r += 1
            num = random.randint(1,ubound)
        nums.append(num)
    # print(r)
    return nums

def getValues(filename, sep=","):
    def listify(value):
        return value.strip().split(sep)
    f = open(filename, "r")
    values = f.readlines()
    f.close()
    return list(map(listify, values))

#-------------------------------------------- FREINDSHIPS---------------------------------------#
# configuration for friends
POPSCALE = 0.25
ucount = int(MAXID * POPSCALE)
fcount = 5 

def friendships(random=True):
    """ generate friendships in random BST like manner. Best to use random mode with  POPSCALE < 0.8 """
    friendlyUsers = {}
    fqueue = []
    friendlyUserCount = 0
    c = 0
    fc = 0
    while friendlyUserCount < ucount and c > -1:
        if friendlyUserCount % 5000 == 0: print(friendlyUserCount)
        c += 1
        
        # randomly or uniformly choose next new user to add to queue
        if fqueue == []:
            if random:
                newu = randomids(list(friendlyUsers.keys()), MAXID, 1) 
            else:
                fc += 1
                newu = [fc]
            fqueue += newu

        # find friends for 1st element in fqueue
        u = fqueue.pop(0)
        
        friendlyUsers[u] = friendlyUsers[u] if u in friendlyUsers else []
        friends = randomids(
            [u] + friendlyUsers[u], 
            MAXID, 
            fcount - len(friendlyUsers[u]))

        # if no friends made user has met quota and no user count does not increase
        if len(friends) > 0: 
            friendlyUserCount += 1

        # add friends to chosen user
        friendlyUsers[u] += friends

        # add user as friend to all generated friends
        for friend in friends:
            if friend in friendlyUsers:
                friendlyUsers[friend] += [u]
            else:
                friendlyUsers[friend] = [u]

        # add generated riends to queue
        fqueue += friends

    return friendlyUsers, friendlyUserCount

def group():
    groups = ["Relative", "School", "Work"]
    return random.choice(groups)

def saveFriendships(filename, friendlyUsers):
    f = open(filename, "w")
    for key,val in friendlyUsers.items():
        for v in val:
            line = f"{key},{v},'{group()}'\n"
            # print(line)
            f.write(line)
    f.close()

def saveFriendships2(filename, friendlyUsers):
    f = open(filename, "w")
    for key,val in friendlyUsers.items():
        line = ",".join([str(key)] + list(map(str, val))) + "\n"
        # print(line)
        f.write(line)
    f.close()

def friendshipsToSql(csv_file, sql_file):
    """
    csv_file = csv file w/ data, 
    sql_file = sql file for insert statement output, 
    """
    values = getValues(csv_file)
    f = open(sql_file, "w")
    for val in values:
        f.write(friend(val[0], val[1], val[2]) + "\n")
    f.close()

 
friendlyUsers, recno = friendships(random=False)
# pprint.pprint(friendlyUsers)
print(len(friendlyUsers))
print(recno)

c = 0
for key,val in friendlyUsers.items():
    if len(val) >= 5:
        c += 1
print(c)

# saveFriendships("friendships.csv", freindlyUsers)
# saveFriendships2("friendships2.csv", freindlyUsers)
# insertTuples("friendships.csv", "friendships.sql", "friendships")
# pprint.pprint(getValues('friendships.csv'))
# friendshipsToSql("friendships.csv", "friendships.sql")
# f.close()
#-------------------------------------------- END FREINDSHIPS---------------------------------------#

#-------------------------------------------- POSTS ---------------------------------------#
# configuration for posts
POSTSCALE = 0.05
upcount = int(MAXID * POSTSCALE)
pcount = 3

def posts(random=True):
    """ generate posts. Best to use random mode with  POPSCALE < 0.8 """
    photos = getPhotos()
    captions = getCaptions()

    userPosts = {}
    uqueue = []
    postUserCount = 0
    c = 0
    while postUserCount < upcount and c > -1:
        if postUserCount % 5000 == 0: print("COUNT:",postUserCount)
        c+=1
        
        # randomly or uniformly choose next new user to add to queue
        if uqueue == []:
            if random:
                newu = randomids(list(userPosts.keys()), MAXID, 1) 
            else:
                newu = [c]
            uqueue += newu

        # make posts for 1st element in fqueue
        u = uqueue.pop(0)
        
        # if user has no posts give them posts
        if u not in userPosts:
            posts = randomPosts(photos, captions, pcount)
            # print(posts)
            userPosts[u] = posts
            postUserCount += 1

    return userPosts, postUserCount

def randomPosts(photos, captions, freq):
    posts = []
    for i in range(freq):
        ptype = random.choice([1,2,3])
        photo = random.choice(photos) if ptype < 3 else ''
        caption = random.choice(captions).strip()
        posts.append((
            photo,
            caption
        ))
    return posts


def getCaptions():
    f = open('captions/captions.txt', "r")
    captions = f.readlines()
    f.close()
    return captions

def getPhotos():
    return os.listdir(os.getcwd() + "/photos")

def savePosts(filename, userPosts):
    f = open(filename, "w")
    for key,val in userPosts.items():
        for v in val:
            line = f"{key}\t{v[0]}\t{v[1]}\n"
            # print(line)
            f.write(line)
    f.close()

def postsToSql(tsv_file, sql_file):
    """
    csv_file = csv file w/ data, 
    sql_file = sql file for insert statement output, 
    """
    values = getValues(tsv_file, sep="\t")
    f = open(sql_file, "w")
    for val in values:
        f.write(post(val[0], val[1], val[2]) + "\n")
    f.close()

# posts()
# userPosts, postUserCount = posts()
# pprint.pprint(userPosts)
# print(postUserCount)
# savePosts("posts.tsv", userPosts)
# postsToSql("posts.tsv", "posts.sql")
#-------------------------------------------- END POSTS ---------------------------------------#

#-------------------------------------------- COMMENTS ---------------------------------------#
def friendshipsToDict(filename):
    idPosts = {}
    # f = open(filename, "r")
    # posts = f.readlines()
    for index, line in enumerate(getValues(filename)):
        uid = int(line[0])

        if uid in idPosts:
            idPosts[uid] += [int(line[1].strip())]
        else:
            idPosts[uid] = [int(line[1].strip())]
    return idPosts

def postsToDict(filename):
    idPosts = {}
    # f = open(filename, "r")
    # posts = f.readlines()
    for index, line in enumerate(getValues(filename, sep="\t")):
        uid = int(line[0])
        pid = index + 1

        idPosts[pid] = [int(uid), line[1], line[2]]
    return idPosts

def getComments():
    f = open('comments/comments.txt', "r")
    comments = f.readlines()
    f.close()
    return comments

def randomComment(comments, freq=1):
    c = []
    for i in range(freq):
        c.append(random.choice(comments).strip())
    return c[0] if freq==1 else c

# Configuration for comments
COMMENTSCALE = 0.05
uccount = int(MAXID * COMMENTSCALE)
ccount = 2

def comments(friendship_file, posts_file, random=True):
    """ generate comments. Best to use random mode with  POPSCALE < 0.8 """
    friendships = friendshipsToDict(friendship_file)
    posts = postsToDict(posts_file)
    comments = getComments()
    maxpost = len(posts)

    commentPosts = {}
    pqueue = []
    commentPostCount = 0
    c = 0
    while commentPostCount < uccount and c > -1:
        if commentPostCount % 5000 == 0: print("COUNT:",commentPostCount)
        c+=1
        
        # randomly or uniformly choose next new user to add to queue
        if pqueue == []:
            if random:
                newu = randomids(list(commentPosts.keys()), maxpost, 1) 
            else:   
                newu = [c]
            pqueue += newu

        # make posts for 1st element in fqueue
        p = pqueue.pop(0)
        
        # if post has no comments, give it comments
        if p not in commentPosts:
            uid = posts[p][0]

            # find friends of owner of post
            friends = friendships[uid] if uid in friendships else []
            # print(friends)
            if friends:
                commentPostCount += 1
                for i in range(ccount):
                    index = i % len(friends)
                    # make each friend leave a comment until quota is met
                    # print("CHOSE FRIEND: ", friends[index])
                    if friends[index] in commentPosts:
                        commentPosts[friends[index]] += [(p, randomComment(comments))]
                    else:
                        commentPosts[friends[index]] = [(p, randomComment(comments))]

    return commentPosts, commentPostCount

def saveComments(filename, commentPosts):
    f = open(filename, "w")
    for key,val in commentPosts.items():
         for v in val:
             line = f'{key}\t{v[0]}\t{v[1]}\n'
             f.write(line)
    f.close()

def commentsToSql(tsv_file, sql_file):
    """
    tsv_file = tsv file w/ data, 
    sql_file = sql file for insert statement output, 
    """
    values = getValues(tsv_file, sep="\t")
    f = open(sql_file, "w")
    for val in values:
        f.write(comment(val[0], val[1], val[2]) + "\n")
    f.close()

# d = postsToDict("posts.tsv")
# f = friendshipsToDict("friendships.csv")
# pprint.pprint(d[1])
# pprint.pprint(f[1])
# commentPosts, commentPostCount = comments("friendships.csv", "posts.tsv")
# pprint.pprint(commentPosts)
# print(commentPostCount) 
# saveComments("comments.tsv", commentPosts)
# commentsToSql("comments.tsv", "comments.sql")
#-------------------------------------------- END COMMENTS ---------------------------------------#