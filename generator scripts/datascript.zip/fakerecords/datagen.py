from faker import Faker
from pprint import pprint
import random

fake = Faker()
limit = 10000

def comments(randomL = False):
    """ gnerate random sentences """
    if not randomL:
        comments = fake.texts(nb_texts = limit,  max_nb_chars=50, ext_word_list=None)
    else:
        comments = []
        for i in range(limit):
            l = random.randint(5, 50)
            comments.append(fake.text(max_nb_chars=l, ext_word_list=None))
    
    return comments

def captions(randomL = False): 
    """ generate random paragraphs/sentences """
    if not randomL:
        captions = fake.texts(nb_texts = limit,  max_nb_chars=75, ext_word_list=None)
    else:
        captions = []
        for i in range(limit):
            l = random.randint(10, 75)
            captions.append(fake.text(max_nb_chars=l, ext_word_list=None))
    
    return captions

def photos():
    """ generate random image urls """
    photos = []
    for i in range(limit):
        photos.append(fake.image_url())
    
    return photos

def group_names():
    """ generate random group names """
    names = []
    for i in range(limit):
        l = random.randint(5, 20)
        names.append(fake.text(max_nb_chars=l))
    
    return names

def saveToTxt(data, filename):
    BASE_DIR = "data/faker/"
    f = open(BASE_DIR + filename, "w")
    for d in data:
        f.write(d + "\n")
    f.close()


# pprint(comments(randomL=True))
# pprint(captions(randomL=True, maxL=70))
# pprint(photos())

# saveToTxt(comments(), "comments.txt")
# saveToTxt(captions(), "captions.txt")
# saveToTxt(photos(), "photos.txt")
saveToTxt(group_names(), "group_names.txt")