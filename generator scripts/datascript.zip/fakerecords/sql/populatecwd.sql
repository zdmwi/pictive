-- increase max packet size allowed (because our files r thiccc)
SET GLOBAL max_allowed_packet=1073741824;

-- user population
\. users.sql

-- friends population
\. friendships.sql

-- post population
\. posts.sql

-- photos
\. photos.sql

--texts
\. texts.sql

-- comments
\. comments.sql

-- groups
\. groups.sql

-- group members
\. members.sql

-- group post population
\. group_posts.sql

-- group post photos
\. group_photos.sql

-- group post texts
\. group_texts.sql

-- group posts_made
\. posts_made.sql

-- wipe profiles
delete from profile;

-- profiles
\. profiles.sql

-- admin
\. admin.sql