-- increase max packet size allowed (because our files r thiccc)
SET GLOBAL max_allowed_packet=1073741824;

-- user population
\. multi_insert/users/users45.sql

-- friends population
\. multi_insert/friendships/friendships.sql

-- post population
\. multi_insert/posts/posts.sql

-- photos
\. multi_insert/posts/photos.sql

--texts
\. multi_insert/posts/texts.sql

-- comments
\. multi_insert/comments/comments.sql

-- groups
\. multi_insert/groups/groups.sql

-- group members
\. multi_insert/groups/members.sql

-- group post population
\. multi_insert/posts/group_posts.sql

-- group post photos
\. multi_insert/posts/group_photos.sql

-- group post texts
\. multi_insert/posts/group_texts.sql

-- group posts_made
\. multi_insert/groups/posts_made.sql

-- wipe profiles
delete from profile;

-- profiles
\. multi_insert/profiles/profiles.sql

-- admin
\. admin.sql