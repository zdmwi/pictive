create table admin(
    admin_id int not null AUTO_INCREMENT,
    email varchar(30),
    password varchar(30),
    primary key(admin_id)
);

insert into admin(email, password) values("admin@relatable.com", "password");