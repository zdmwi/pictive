import random
import os
import pprint
from utils import *

CALL = "CALL"
FRIEND = "addFriend"

def friend(uid, fid, type):
    return f"{CALL} {FRIEND}({uid}, {fid}, '{type}');"

#-------------------------------------------- FREINDSHIPS---------------------------------------#
# configuration for friends
SCALE = 1
fcount = 5 

def friendships2(random=True):
    """ generate friendships in random BST like manner. Best to use random mode with  POPSCALE < 0.8 """
    friendlyUsers = {}
    fqueue = []
    friendlyUserCount = 0
    ucount = int(MAXID * SCALE)
    c = 0
    fc = 0

    print("FRIENDSHIP")
    while friendlyUserCount < ucount and c > -1:
        if friendlyUserCount % 5000 == 0: print(friendlyUserCount)
        c += 1
        
        # randomly or uniformly choose next new user to add to queue
        if fqueue == []:
            if random:
                # newu = randomids(list(friendlyUsers.keys()), MAXID, 1) 
                newu = randomids(friendlyUsers, MAXID, 1) 
            else:
                fc += 1
                newu = [fc]
            fqueue += newu

        # find friends for 1st element in fqueue
        u = fqueue.pop(0)
        
        # friendlyUsers[u] = friendlyUsers[u] if u in friendlyUsers else []
        friendlyUsers[u] = friendlyUsers[u] if inSeq(u, friendlyUsers) else set()
        friends = randomids(
            # [u] + friendlyUsers[u], 
            set([u]).union(friendlyUsers[u]),
            MAXID, 
            fcount - len(friendlyUsers[u]))

        # if no friends made user has met quota and no user count does not increase
        if len(friends) > 0: 
            friendlyUserCount += 1

            # add friends to chosen user
            # friendlyUsers[u] += friends
            friendlyUsers[u] = friendlyUsers[u].union(set(friends))

        # add user as friend to all generated friends
        for friend in friends:
            # if friend in friendlyUsers:
            if inSeq(friend, friendlyUsers):
                # friendlyUsers[friend] += [u]
                friendlyUsers[friend].add(u)
            else:
                # friendlyUsers[friend] = [u]
                friendlyUsers[friend] = set([u])

        # add generated friends to queue
        # fqueue += friends
        fqueue += list(friends)

    return friendlyUsers, friendlyUserCount

def friendships(random=True):
    """ generate friendships in random BST like manner. Best to use random mode with  POPSCALE < 0.8 """
    friendlyUsers = {}
    fqueue = []
    friendlyUserCount = 0
    ucount = int(MAXID * SCALE)
    c = 0
    fc = 0

    print("FRIENDSHIP")
    while friendlyUserCount < ucount and c > -1:
        if friendlyUserCount % 5000 == 0: print(friendlyUserCount)
        c += 1
        
        # randomly or uniformly choose next new user to add to queue
        if fqueue == []:
            if random:
                # newu = randomids(list(friendlyUsers.keys()), MAXID, 1) 
                newu = randomids(friendlyUsers, MAXID, 1) 
            else:
                fc += 1
                newu = [fc]
            fqueue += newu

        # find friends for 1st element in fqueue
        u = fqueue.pop(0)
        
        # friendlyUsers[u] = friendlyUsers[u] if u in friendlyUsers else []
        friendlyUsers[u] = friendlyUsers[u] if inSeq(u, friendlyUsers) else set()
        friends = randomids(
            set([u]).union(friendlyUsers[u]),
            MAXID, 
            fcount - len(friendlyUsers[u]))

        # if no friends made user has met quota and no user count does not increase
        if friends:
            friendlyUserCount += 1
        # print(friends)
        while friends:
            #check if friendship exists
            # print("FRIEND:",friends[0])
            if inSeq(friends[0], friendlyUsers) and u in friendlyUsers[friends[0]]:
                #friendship exists
                print("REPEAT")
                print("FRIEND:",friends[0])
                friends += randomids(
                    set([u]).union(friendlyUsers[u]),
                    MAXID, 
                    1)  
            else:
                friendlyUsers[u].add(friends[0])

            friends.remove(friends[0])

    return friendlyUsers, friendlyUserCount

def group():
    groups = ["Relative", "School", "Work"]
    return random.choice(groups)

def saveFriendships(filename, friendlyUsers):
    f = open(filename, "w")
    for key,val in friendlyUsers.items():
        for v in val:
            line = f"{key},{v},{group()}\n"
            # print(line)
            f.write(line)
    f.close()

def saveFriendships2(filename, friendlyUsers):
    f = open(filename, "w")
    for key,val in friendlyUsers.items():
        line = ",".join([str(key)] + list(map(str, val))) + "\n"
        # print(line)
        f.write(line)
    f.close()

def friendshipsToSP(csv_file, sql_file, split=False):
    """
    csv_file = csv file w/ data, 
    sql_file = sql file for insert statement output, 
    """
    dir_pref = "sql/stored_procedures/friendships/"
    rec_per_file = 200000
    fileno = 0
    values = getValues(csv_file)
    f = open(dir_pref + sql_file, "w")
    for i, val in enumerate(values):
        if split and i % rec_per_file == 0:
            f.close()
            f = open(dir_pref  + str(fileno) + sql_file, "w")
            fileno += 1
        
        f.write(friend(val[0], val[1], val[2]) + "\n")
    f.close()

def friendshipsToMI(csv_file, sql_file, split=False):
    """
    csv_file = csv file w/ data, 
    sql_file = sql file for insert statement output, 
    """
    tablename = "friend_of" # name of table to insert data in database
    colnames = ["user_id", "friend_id", "group_t"]
    dir_pref = "sql/multi_insert/friendships/"
    rec_per_file = 200000
    BASE = f"INSERT INTO {tablename}({','.join(colnames)}) VALUES "

    values = getValues(csv_file)
    # print(values) 
    fileno = 0
    f = open(dir_pref  + str(fileno) + sql_file, "w") if split else open(dir_pref + sql_file, "w")
    
    f.write(BASE + "\n")
    for i, val in enumerate(values[:-1], start=1):
        if split and i % rec_per_file == 0:
            f.write(f'\t("{val[0]}", "{val[1]}", "{val[2]}");')
            f.close()
            fileno += 1
            f = open(dir_pref  + str(fileno) + sql_file, "w")
            f.write(BASE + "\n")
        
        f.write(f'\t("{val[0]}", "{val[1]}", "{val[2]}"),\n')

    val = values[-1]
    f.write(f'\t("{val[0]}", "{val[1]}", "{val[2]}");')  
    f.close()

def insertTuples(csv_file, sql_file, tablename, colnames):
    """
    csv_file = csv file w/ data, 
    sql_file = sql file for insert statement output, 
    tablename = name of table to insert data in database
    """
    dir_pref = "sql/users/"
    BASE = f"INSERT INTO {tablename}({','.join(colnames)}) VALUES "
    file = open(dir_pref + sql_file, "w")
    values = csvToTuples(csv_file)
    file.write(BASE + "\n" + values + ";")
    file.close()

def gen(random=True):
    friendlyUsers, recno = friendships2(random=random)
    # pprint.pprint(friendlyUsers)
    print("NO. of Records:",len(friendlyUsers))

    c = 0
    for key,val in friendlyUsers.items():
        if len(val) >= 5:
            c += 1
    print("Records meeting quota:", c)
    print("MAX ID#:", max(friendlyUsers.keys()))

    saveFriendships("records/friendships.csv", friendlyUsers)
    # saveFriendships2("records/friendships2.csv", friendlyUsers)

def sql():
    # stored procedures
    # friendshipsToSP("records/friendships.csv", "friendships.sql", split=False)

    # multi insert
    friendshipsToMI("records/friendships.csv", "friendships.sql", split=False)

def populate(scale=1, random=True):
    global SCALE
    SCALE = scale
    gen(random=random)
    sql()
    

# f, c = friendships()
# print(f)
# pprint.pprint(getValues('friendships.csv'))
# sql()
#-------------------------------------------- END FREINDSHIPS---------------------------------------#
