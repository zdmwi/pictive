from faker import Faker
from random import randint, choice
import string

letters = string.ascii_letters

class Person():
    """ Class representing a person in the db - # id, fname, lname, gender, dob, telephone, email """
    ID = 1
    GENDERS = ['M', 'F']
    GENDER_NUM = len(GENDERS)
    MIN_AGE = 10
    MAX_AGE = 90

    def __init__(self, fake):
        self.id = Person.ID
        Person.ID += 1
        self.gender = Person.GENDERS[randint(0,Person.GENDER_NUM-1)]
        if self.gender == 'M':
            self.fname = fake.first_name_male()
        else:
            self.fname = fake.first_name_female()
        self.lname = fake.last_name()
        self.dob = fake.date_of_birth(minimum_age=Person.MIN_AGE, maximum_age=Person.MAX_AGE)
        self.telephone = fake.phone_number()
        self.email = fake.email()

    def __repr__(self):
        rep = f"<Person {self.id} {self.fname} {self.lname} {self.gender} {self.dob} {self.telephone} {self.email} "
        return rep

count = 10000
fake = Faker()
# genders = ['M', 'F']
# gender_count = len(genders)
# print(fake.name())
# profile = fake.profile(fields=["name", "sex", "mail", "birthdate"])
# print(profile)
# print(profile.name)

def print_persons():

    for i in range(count):
        id = i
        gender = genders[randint(0,gender_count-1)]
        if gender == 'M':
            fname = fake.first_name_male()
        else:
            fname = fake.first_name_female()
        lname = fake.last_name()
        dob = fake.date_of_birth(minimum_age=10, maximum_age=90)
        telephone = fake.phone_number()
        email = fake.email()

        print(id)
        print(fname)
        print(lname)
        print(gender)
        print(dob)
        print(telephone)
        print(email)
        print()

def generate():
    for i in range(count):
        p = Person(fake)
        print(p)
        print()



def gen_person():
    """ Much slower implementation of above function """
    for i in range(count):
        profile = fake.profile(fields=["name", "sex", "mail", "birthdate"])
        name = profile["name"].split()

        id = i
        fname = name[0]
        lname = name[1]
        gender = profile["sex"]
        dob = profile["birthdate"]
        telephone = fake.phone_number()
        email = profile["mail"]

        print(id)
        print(fname)
        print(lname)
        print(gender)
        print(dob)
        print(telephone)
        print(email)
        print()

generate()


class User():

    ID = 1

    def __init__(self, fake):
        self.fname = fake.first_name
        self.lname = fake.last_name
        self.password = 4
        self.email = fake.email()

    