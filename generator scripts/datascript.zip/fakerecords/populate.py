import user_records, friendships, posts, comments, groups, profiles

SCALE = 0.7
user_records.populate(scale=SCALE)
friendships.populate(scale=SCALE, random=False)
posts.populate(scale=SCALE)
comments.populate(scale=SCALE)
groups.populate(scale=0.3)
profiles.populate(scale=SCALE)
