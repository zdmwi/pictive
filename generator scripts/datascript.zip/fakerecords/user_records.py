from faker import Faker
from random import randint, choice
import string
from utils import *

CALL = "CALL"
USER = "register"
SCALE = 1

def user(fname, lname, password, email):
    return f'{CALL} {USER}("{fname}", "{lname}", "{password}", "{email}");'

# Record configuration
RECCOUNT = MAXID * SCALE
fake = Faker()

# Password
letters = string.ascii_letters
MIN_PASS_LENGTH = 5
MAX_PASS_LENGTH = 20

def generateString(minimum, maximum):
    """ generate a random string within a given range by randomly picking letters of the alphabet """
    length = randint(minimum, maximum)
    return ''.join(choice(letters) for i in range(length))

def generatePassword():
    """ generate a password - random string """
    return generateString(MIN_PASS_LENGTH, MAX_PASS_LENGTH)

class User():
    """ class representing a User... kinda unnecessary depending how u look at it """

    ID_PREFIX = "USER"
    ID = 0

    def __init__(self, fake):
        self.id = self.getID()
        self.fname = fake.first_name()
        self.lname = fake.last_name()
        self.password = generatePassword()
        self.email = fake.email()

    def getID(self):
        User.ID += 1
        return User.ID_PREFIX + str(User.ID)

    def values(self):
        # return f"{self.id}, {self.fname}, {self.lname}, {self.password}, {self.email}"
        return [
            # self.id,
            self.fname,
            self.lname,
            self.password,
            self.email
        ]

    def csv_values(self):
        return ",".join(self.values())

    def tsv_values(self):
        return "\t".join(self.values())
    
    def __repr__(self):
        return f"<User(id={self.id}, fname={self.fname}, lname={self.lname}, password={self.password}, email={self.email})>"


def quotify(string):
    return "\'" + string + "\'"

def generate(count):
    """ function to just print 'count' number of fake records """
    for i in range(count):
        user = User(fake)
        print(user, end='\n\n')

# generate(50)

def generateToFile(filename):
    """ Generate fake data to csv file """
    file = open(filename, 'w')
    for i in range(RECCOUNT):
        if i % 5000 == 0: print(i)
        user = User(fake)
        file.write(user.tsv_values() + '\n')
    file.close()

# generateToFile('users.csv')

def usersToSql(csv_file, sql_file):
    """
    csv_file = csv file w/ data, 
    sql_file = sql file for insert statement output, 
    """
    dir_pref = "sql/users/"
    values = getValues(csv_file)
    f = open(dir_pref + sql_file, "w")
    for val in values:
        f.write(user(val[0], val[1], val[2], val[3]) + "\n")
    f.close()

def insertTuples(csv_file, sql_file, tablename, colnames):
    """
    csv_file = csv file w/ data, 
    sql_file = sql file for insert statement output, 
    tablename = name of table to insert data in database
    """
    dir_pref = "sql/users/"
    BASE = f"INSERT INTO {tablename}({','.join(colnames)}) VALUES "
    file = open(dir_pref + sql_file, "w")
    values = getValues(csv_file)
    lines = ""
    print(values)
    for v in values[:-1]:
        lines += f"({v[0]}, {v[1]}, {v[2]}),\n"
    v = values[-1]
    lines += f"({v[0]}, {v[1]}, {v[2]});\n"
    file.write(BASE + "\n" + lines)
    file.close()

def usersToMI(csv_file, sql_file):
    """
    csv_file = csv file w/ data, 
    sql_file = sql file for insert statement output, 
    """
    tablename = "users" # name of table to insert data in database
    colnames = ["fname","lname","password","email"]
    dir_pref = "sql/multi_insert/users/"
    BASE = f"INSERT INTO {tablename}({','.join(colnames)}) VALUES "

    values = getValues(csv_file, sep="\t")
    # print(values) 
    f = open(dir_pref + sql_file, "w")
    
    f.write(BASE + "\n")
    for i, val in enumerate(values[:-1], start=1):        
        f.write(f'\t("{val[0]}", "{val[1]}", "{val[2]}", "{val[3]}"),\n')

    val = values[-1]
    f.write(f'\t("{val[0]}", "{val[1]}", "{val[2]}", "{val[3]}");')  
    f.close()

def sql():
    usersToMI("records/users.csv", "users.sql")
    # insertTuples('users.csv', 'users.sql', 'users', ("fname","lname","password","email"))

def gen():
    generateToFile('records/users.csv')

def populate(scale=1):
    global SCALE
    SCALE = scale
    gen()
    sql()
# print(csvToTuples('users.csv'))
# generateToFile('users.csv')
# insertTuples('users.csv', 'users.sql', 'users', ("fname","lname","password","email"))
# sql()
# usersToSql("users.csv", "usersSP.sql")