
## making virtual environment

### with virtualenv
create virtual env with python eg.

`virtualenv env`

activate virtual environment

`source env/bin/activate`

## install faker module for users
`pip install faker`

### populate
create csv/tsv files with records and sql file for execution

`python3 populate.py`

### where to find data
~ records folder contains all csv/tsv data

~ sql/muli_insert/ contains all generated sql files

### how to populate DB
navigate to src folder of full.sql then execute said file in mysql shell

`\. full.sql`

