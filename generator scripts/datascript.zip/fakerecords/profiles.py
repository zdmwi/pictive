from posts import getCaptions, getPhotos, randomPosts
from utils import *
from pprint import pprint

SCALE = 1
DEFAULT_IMG = "https://upload.wikimedia.org/wikipedia/commons/7/7c/Profile_avatar_placeholder_large.png"

def modifyPhoto(uid, url):
    return f'CALL modifyProfilePhoto({uid}, "{url}");'

def modifyStatus(uid, status):
    return f'CALL modifyProfileStatus({uid}, "{status}");'

def profiles():
    profileDict = {}
    ucount = int(MAXID * SCALE)
    photos = getPhotos()
    statuses = getCaptions()
    pcount = 0
    for i in range(ucount):
        if pcount % 5000 == 0: print(pcount)
        user = i + 1
        profile = randomPosts(photos, statuses, 1, DEFAULT_IMG)[0]
        profileDict[user] = profile
        pcount += 1
    return profileDict

def saveProfiles(filename, profiles):
    f = open(filename, "w")
    for key,val in profiles.items():
        line = f"{key}\t{val[0]}\t{val[1]}\n"
        f.write(line)
    f.close()

def profilesToMI(data_file, sql_file):
    """
    data_file = csv file w/ data, 
    sql_file = sql file for insert statement output, 
    """
    tablename = "profile" # name of table to insert data in database
    colnames = ["user_id", "profile_photo", "status"]
    dir_pref = "sql/multi_insert/profiles/"
    BASE = f"INSERT INTO {tablename}({','.join(colnames)}) VALUES "

    values = getValues(data_file, sep="\t")
    f = open(dir_pref + sql_file, "w")
    
    f.write(BASE + "\n")
    for i, val in enumerate(values[:-1], start=1):
        f.write(f'\t({val[0]}, "{val[1]}", "{val[2]}"),\n')

    val = values[-1]
    f.write(f'\t({val[0]}, "{val[1]}", "{val[2]}");')  
    f.close()

def profilesToSP(data_file, sql_file):
    """
    data_file = csv file w/ data, 
    sql_file = sql file for insert statement output, 
    """
    dir_pref = "sql/stored_procedures/profiles/"

    values = getValues(data_file, sep="\t")
    f = open(dir_pref + sql_file, "w")
    
    for i, val in enumerate(values[:-1], start=1):
        f.write(modifyPhoto(val[0], val[1]) + "\n")
        f.write(modifyStatus(val[0], val[2]) + "\n")
    f.close()

def gen():
    profileDict = profiles()
    pprint(profileDict)
    saveProfiles("records/profiles.tsv", profileDict)

def sql():
    # profilesToSP("records/profiles.tsv", "profiles.sql")
    profilesToMI("records/profiles.tsv", "profiles.sql")

def populate(scale=1):
    global SCALE
    SCALE = scale
    gen()
    sql()

# populate()


