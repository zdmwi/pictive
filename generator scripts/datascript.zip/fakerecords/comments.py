import random
import os
import pprint
from datetime import datetime
from utils import *

CALL = "CALL"
COMMENT = "leaveComment"

def comment(uid, pid, comment):
    return f'{CALL} {COMMENT}({uid}, {pid}, "{comment}");'

#-------------------------------------------- COMMENTS ---------------------------------------#
# Configuration for comments
SCALE = 0.25
ccount = 2

def comments(friendship_file, posts_file, random=True):
    """ generate comments. Best to use random mode with  POPSCALE < 0.8 """
    friendships = friendshipsToDict(friendship_file)
    posts = postsToDict(posts_file)
    comments = getComments()
    
    maxpost = len(posts) - 1
    commentPosts = {}
    pqueue = []
    commentPostCount = 0
    uccount = int(MAXID * SCALE)
    c = 0
    
    print("COMMENTS", maxpost)
    while commentPostCount < uccount and c > -1:
        if commentPostCount % 5000 == 0: print("COUNT:",commentPostCount)
        c+=1
        
        # randomly or uniformly choose next new user to add to queue
        if pqueue == []:
            if random:
                newu = randomids(commentPosts, maxpost, 1) 
            else:   
                newu = [c]
            pqueue += newu

        # make posts for 1st element in fqueue
        p = pqueue.pop(0)
        
        # if post has no comments, give it comments
        if not inSeq(p, commentPosts):
            uid = posts[p][0]

            # find friends of owner of post
            friends = friendships[uid] if uid in friendships else []
            if friends:
                commentPostCount += 1
                for i in range(ccount):
                    index = i % len(friends)
                    # make each friend leave a comment until quota is met
                    if inSeq(friends[index], commentPosts):
                        commentPosts[friends[index]] += [(p, randomComment(comments))]
                    else:
                        commentPosts[friends[index]] = [(p, randomComment(comments))]

    return commentPosts, commentPostCount

def friendshipsToDict(filename):
    idPosts = {}
    for index, line in enumerate(getValues(filename)):
        uid = int(line[0])

        if uid in idPosts:
            idPosts[uid] += [int(line[1].strip())]
        else:
            idPosts[uid] = [int(line[1].strip())]
    return idPosts

def postsToDict(filename):
    idPosts = {}
    for index, line in enumerate(getValues(filename, sep="\t"), start=1):
        uid = int(line[0])
        pid = index

        idPosts[pid] = [int(uid), line[1], line[2]]
    return idPosts

def getComments(manual=False):
    BASE_DIR = "data/manual/" if manual else "data/faker/"
    f = open(BASE_DIR + 'comments.txt', "r")
    comments = f.readlines()
    f.close()
    return comments

def randomComment(comments, freq=1):
    c = []
    for i in range(freq):
        c.append(random.choice(comments).strip())
    return c[0] if freq==1 else c

def saveComments(filename, commentPosts):
    f = open(filename, "w")
    for key,val in commentPosts.items():
         for v in val:
             line = f'{key}\t{v[0]}\t{v[1]}\n'
             f.write(line)
    f.close()

def commentsToSql(tsv_file, sql_file, split=False):
    """
    tsv_file = tsv file w/ data, 
    sql_file = sql file for insert statement output, 
    """
    dir_pref = "sql/stored_procedures/comments/"
    rec_per_file = 200000
    values = getValues(tsv_file, sep="\t")
    fileno = 0
    f = open(dir_pref  + str(fileno) + sql_file, "w") if split else open(dir_pref + sql_file, "w")
    for i, val in enumerate(values, start=1):
        if split and i % rec_per_file == 0:
            f.close()
            f = open(dir_pref  + str(fileno) + sql_file, "w")
            fileno += 1
        
        f.write(comment(val[0], val[1], val[2]) + "\n")
    f.close()

def commentsToMI(csv_file, sql_file, split=False):
    """
    csv_file = csv file w/ data, 
    sql_file = sql file for insert statement output, 
    """
    tablename = "comments_on" # name of table to insert data in database
    colnames = ["user_id", "post_id", "comment", "c_date"]
    dir_pref = "sql/multi_insert/comments/"
    rec_per_file = 200000
    BASE = f"INSERT INTO {tablename}({','.join(colnames)}) VALUES "

    values = getValues(csv_file, sep="\t")
    # print(values) 
    fileno = 0
    f = open(dir_pref  + str(fileno) + sql_file, "w") if split else open(dir_pref + sql_file, "w")
    
    f.write(BASE + "\n")
    print(values[0])
    for i, val in enumerate(values[:-1], start=1):
        if split and i % rec_per_file == 0:
            now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            f.write(f'\t({val[0]}, {val[1]}, "{val[2]}", "{now}");')
            f.close()
            fileno += 1
            f = open(dir_pref  + str(fileno) + sql_file, "w")
            f.write(BASE + "\n")
        
        now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        f.write(f'\t({val[0]}, {val[1]}, "{val[2]}", "{now}"),\n')

    val = values[-1]
    now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    f.write(f'\t({val[0]}, {val[1]}, "{val[2]}", "{now}");')  
    f.close()

def gen(random=True):
    commentPosts, commentPostCount = comments("records/friendships.csv", "records/posts.tsv", random=random)
    # pprint.pprint(commentPosts)
    # print(commentPostCount) 
    print("NO. of Records:",len(commentPosts))
    print("MAX ID#:", max(commentPosts.keys()))
    saveComments("records/comments.tsv", commentPosts)

def sql(split=False):
    # stored procedures
    # commentsToSql("records/comments.tsv", "comments.sql", split=False)

    # multi insert
    commentsToMI("records/comments.tsv", "comments.sql", split=False)


def populate(scale=1, random=True):
    global SCALE
    SCALE = scale
    gen(random=random)
    sql()
#-------------------------------------------- END COMMENTS ---------------------------------------#
