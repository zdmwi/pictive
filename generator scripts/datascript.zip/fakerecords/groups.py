import random
import os
import pprint
from datetime import datetime
from utils import *
from posts import getCaptions, getPhotos, randomPosts, postsToMI

# configuration
SCALE = 0.3
memcount = 10
editorcount = 3
pcount = 5

def groups():
    """ generate groups to be made """
    names = getNames()
    groups = {}
    groupCount = 0
    gcount = int(SCALE * MAXID)

    c = 0
    print("GROUPS")
    while groupCount < gcount and c > -1:
        if groupCount % 5000 == 0: print("COUNT:", groupCount)
        c += 1

        # randomly choose user to own group
        user = randomids(set(), MAXID, 1)[0]

        groups[user] = groups[user] if inSeq(user, groups) else []

        # assign user group with members
        groups[user].append((  
            # id
            groupCount + 1, # 0

            # name
            random.choice(names).strip(), # 1

            # members with default view roles
            setRoles([ [x, "viewer"] for x in randomids([user],MAXID,memcount)]) # 2
        ))  
        groupCount += 1

    return groups, groupCount

def group_posts(groupDict):
    captions = getCaptions()
    photos = getPhotos() 
    pid = len(getValues("records/posts.tsv")) + 1 # 1050001
    gposts = {}
    for user, groups in groupDict.items():
        for group in groups:
            editors = list(filter(lambda x: x[1] == "editor", group[2]))
            for p in range(pcount):
                editor = random.choice(editors)[0]
                gposts[pid] = (
                    editor,
                    group[0],
                    randomPosts(photos, captions, 1)[0]
                )
                pid += 1
    print("MAX POST ID", pid)
    return gposts

def saveGroupPosts(filename, groupPosts):
    f = open(filename, "w")
    for key, val in groupPosts.items():
        uid = val[0]
        group = val[2]
        photo = group[0]
        caption = group[1]
        line = f"{key}\t{uid}\t{photo}\t{caption}\n"
        f.write(line)
    f.close()

def saveLinkedGroupPosts(filename, groupPosts):
    f = open(filename, "w")
    for key, val in groupPosts.items():
        line = f'{key}\t{val[0]}\t{val[1]}\n'
        f.write(line)
    f.close()

def getNames(manual=False):
    BASE_DIR = "data/manual/" if manual else "data/faker/"
    f = open(BASE_DIR + 'group_names.txt', "r")
    names = f.readlines()
    f.close()
    return names

def setRoles(members):
    ecount = 0
    while ecount < editorcount:
        i = random.randint(1,len(members)-1)
        if members[i][1] != "editor":
            members[i][1] = "editor"
            ecount += 1
    return members

def saveGroups(grp_file, member_file, groupDict):
    f = open(grp_file, "w")
    m = open(member_file, "w")
    id = 1
    for index, value in groupDict.items():
        # print(value)
        for v in value:
            f.write(f'{v[0]}\t{index}\t{v[1]}\n')
            for w in v[2]:  
                m.write(f'{w[0]}\t{v[0]}\t{w[1]}\n')
        id += 1
    f.close()
    m.close()

def groupsToMI(data_file, sql_file):
    """
    data_file = csv file w/ data, 
    sql_file = sql file for insert statement output, 
    """
    tablename = "user_groups" # name of table to insert data in database
    colnames = ["group_id", "user_id", "name"]
    dir_pref = "sql/multi_insert/groups/"
    BASE = f"INSERT INTO {tablename}({','.join(colnames)}) VALUES "

    values = getValues(data_file, sep="\t")
    # print(values) 
    f = open(dir_pref + sql_file, "w")
    
    f.write(BASE + "\n")
    for i, val in enumerate(values[:-1], start=1):
        f.write(f'\t({val[0]}, {val[1]}, "{val[2]}"),\n')

    val = values[-1]
    f.write(f'\t({val[0]}, {val[1]}, "{val[2]}");')  
    f.close()

def membersToMI(data_file, sql_file):
    """
    data_file = csv file w/ data, 
    sql_file = sql file for insert statement output, 
    """
    tablename = "joined_group" # name of table to insert data in database
    colnames = ["user_id", "group_id", "role"]
    dir_pref = "sql/multi_insert/groups/"
    BASE = f"INSERT INTO {tablename}({','.join(colnames)}) VALUES "

    values = getValues(data_file, sep="\t")
    f = open(dir_pref + sql_file, "w")
    
    f.write(BASE + "\n")
    for i, val in enumerate(values[:-1], start=1):
        f.write(f'\t({val[0]}, {val[1]}, "{val[2]}"),\n')

    val = values[-1]
    f.write(f'\t({val[0]}, {val[1]}, "{val[2]}");')  
    f.close()

def postsMadeToMI(data_file, sql_file):
    """
    data_file = csv file w/ data, 
    sql_file = sql file for insert statement output, 
    """
    tablename = "posts_made" # name of table to insert data in database
    colnames = ["post_id", "user_id", "group_id"]
    dir_pref = "sql/multi_insert/groups/"
    BASE = f"INSERT INTO {tablename}({','.join(colnames)}) VALUES "

    values = getValues(data_file, sep="\t")
    f = open(dir_pref + sql_file, "w")
    
    f.write(BASE + "\n")
    for i, val in enumerate(values[:-1], start=1):
        f.write(f'\t({val[0]}, {val[1]}, {val[2]}),\n')

    val = values[-1]
    f.write(f'\t({val[0]}, {val[1]}, {val[2]});')  
    f.close()

def groupPostsToMI(csv_file, sql_file, sql_file_t, sql_file_p):
    """
    csv_file = csv file w/ data, 
    sql_file = sql file for insert statement output, 
    """
    tablename = "posts" # name of table to insert data in database
    tablename_t = "texts" # name of table to insert data in database
    tablename_p = "photos" # name of table to insert data in database

    colnames = ["post_id", "user_id", "created_on"]
    colnames_t = ["post_id", "body"]
    colnames_p = ["post_id", "url", "caption"]

    BASE = f"INSERT INTO {tablename}({','.join(colnames)}) VALUES "
    BASE_T = f"INSERT INTO {tablename_t}({','.join(colnames_t)}) VALUES "
    BASE_P = f"INSERT INTO {tablename_p}({','.join(colnames_p)}) VALUES "

    dir_pref = "sql/multi_insert/posts/"

    fileno = 0
    fileno_t = 0
    fileno_p = 0

    values = getValues(csv_file, sep="\t")

    f = open(dir_pref + sql_file, "w")
    t = open(dir_pref + sql_file_t, "w")
    p = open(dir_pref + sql_file_p, "w")

    p_n = 0
    t_n = 0

    f.write(BASE + "\n")
    t.write(BASE_T + "\n")
    p.write(BASE_P + "\n")

    for i, val in enumerate(values, start=1):
        # posts table
        if i != 1: f.write(",\n")
        now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        f.write(f'\t({val[0]}, {val[1]}, "{now}")')

        # photos table
        if val[2]:
            p_n += 1
            if p_n != 1: p.write(",\n")
            p.write(f'\t({val[0]}, "{val[2]}", "{val[3]}")')
        
        # texts table
        else:
            t_n += 1
            if t_n != 1: t.write(",\n")
            t.write(f'\t({val[0]}, "{val[3]}")')

    f.write(";")
    if t_n != 0: t.write(";")
    if p_n != 0: p.write(";")
    f.close()
    t.close()
    p.close()

def gen():
    print("GENERATION")
    groupDict, groupCount = groups()
    gposts = group_posts(groupDict)
    saveGroups("records/groups.tsv", "records/members.tsv", groupDict)
    saveGroupPosts("records/group_posts.tsv", gposts)
    saveLinkedGroupPosts("records/posts_made.tsv", gposts)

def sql(split=False):
    print("SQL")
    # # multi insert
    groupsToMI("records/groups.tsv", "groups.sql")
    membersToMI("records/members.tsv", "members.sql")
    groupPostsToMI("records/group_posts.tsv", "group_posts.sql", "group_texts.sql", "group_photos.sql")
    postsMadeToMI("records/posts_made.tsv", "posts_made.sql")
    pass

def populate(scale=1, random=True):
    global SCALE
    SCALE = scale
    gen()
    sql()

# populate(scale=0.3)
# groupDict, groupCount = groups()
# gposts = group_posts(groupDict)
# invalid_keys = list(filter(lambda x: x > 1800000, gposts.keys()))
# print(invalid_keys)