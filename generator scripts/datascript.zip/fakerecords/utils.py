import random

MAXID = 500

# utility
def randomids(blacklist, ubound, freq):
    nums = []
    r = 0
    # random.seed()
    random.randint(1,5)
    for i in range(freq):
        num = random.randint(1,ubound)
        # while num in blacklist:
        while inSeq(num, blacklist) or num in nums:
            r += 1
            num = random.randint(1,ubound)
        nums.append(num)
        # addTo(blacklist, num)
    # print(r)
    return nums

def getValues(filename, sep=","):
    def listify(value):
        return value.strip().split(sep)
    f = open(filename, "r")
    values = f.readlines()
    f.close()
    return list(map(listify, values))

def csvToTuples(filename):
    """  """
    values = ''
    file = open(filename, 'r')
    records = file.readlines()
    for line in records[:-1]:
        values += f"\t({line.strip()}),\n"
    values += f"\t({records[-1].strip()})"
    file.close()

    return values

def inSeq(keyVal, seq):
    if type(seq) == list or type(seq) == tuple or type(seq) == set:
        return keyVal in seq
    elif type(seq) == dict:
        try:
            v = seq[keyVal]
            return True
        except KeyError as e:
            return False
    else:
        raise Exception

def addTo(seq, val):
    if type(seq) == list:
        seq.append(val)
    elif type(seq) == set:
        seq.add(val)
    elif type(seq) == dict:
        seq[val] = None
    return seq