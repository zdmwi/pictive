import random
import os
import pprint
from datetime import datetime
from utils import *

CALL = "CALL"
PHOTOPOST = "makePhotoPost"
TEXTPOST = "makeTextPost"

def post(uid, photo="", caption=""):
    if not photo:
        return f'{CALL} {TEXTPOST}({uid}, "{caption}");'
    return f'{CALL} {PHOTOPOST}({uid}, "{photo}", "{caption}");'

#-------------------------------------------- POSTS ---------------------------------------#
# configuration for posts
SCALE = 1
pcount = 3

def posts(random=True):
    """ generate posts. Best to use random mode with  POPSCALE < 0.8 """
    upcount = int(MAXID * SCALE)
    photos = getPhotos()
    captions = getCaptions()

    userPosts = {}
    uqueue = []
    postUserCount = 0
    c = 0

    print("POSTS")
    while postUserCount < upcount and c > -1:
        if postUserCount % 5000 == 0: print("COUNT:",postUserCount)
        c+=1
        
        # randomly or uniformly choose next new user to add to queue
        if uqueue == []:
            if random:
                newu = randomids(userPosts, MAXID, 1) 
            else:
                newu = [c]
            uqueue += newu

        # make posts for 1st element in fqueue
        u = uqueue.pop(0)
        
        # if user has no posts give them posts
        if not inSeq(u, userPosts):
            posts = randomPosts(photos, captions, pcount)
            userPosts[u] = posts
            postUserCount += 1

    return userPosts, postUserCount

def randomPosts(photos, captions, freq, default=''):
    posts = []
    for i in range(freq):
        ptype = random.randint(1,3)
        photo = random.choice(photos).strip() if ptype < 3 else default
        caption = random.choice(captions).strip()
        posts.append([
            photo,
            caption
        ])
    return posts


def getCaptions(manual=False):
    BASE_DIR = "data/manual/" if manual else "data/faker/"
    f = open(BASE_DIR + 'captions.txt', "r")
    captions = f.readlines()
    f.close()
    return captions

def getPhotos(manual=False):
    BASE_DIR = "data/manual/" if manual else "data/faker/"
    f = open(BASE_DIR + 'photos.txt', "r")
    photos = f.readlines()
    f.close()
    return photos

def getPhotos2():
    return os.listdir(os.getcwd() + "/data/manual/photos")

def savePosts(filename, userPosts):
    f = open(filename, "w")
    for key,val in userPosts.items():
        for v in val:
            line = f"{key}\t{v[0]}\t{v[1]}\n"
            f.write(line)
    f.close()

def postsToSql(tsv_file, sql_file, split=False):
    """
    csv_file = csv file w/ data, 
    sql_file = sql file for insert statement output, 
    """
    dir_pref = "sql/stored_procedures/posts/"
    rec_per_file = 200000
    values = getValues(tsv_file, sep="\t")
    fileno = 0
    f = open(dir_pref  + str(fileno) + sql_file, "w") if split else open(dir_pref + sql_file, "w")
    for i, val in enumerate(values, start=1):
        if split and i % rec_per_file == 0:
            f.close()
            f = open(dir_pref  + str(fileno) + sql_file, "w")
            fileno += 1
        
        f.write(post(val[0], val[1], val[2]) + "\n")
    f.close()

def postsToMI(csv_file, sql_file, sql_file_t, sql_file_p, split=False):
    """
    csv_file = csv file w/ data, 
    sql_file = sql file for insert statement output, 
    """
    tablename = "posts" # name of table to insert data in database
    tablename_t = "texts" # name of table to insert data in database
    tablename_p = "photos" # name of table to insert data in database

    colnames = ["user_id", "created_on"]
    colnames_t = ["post_id", "body"]
    colnames_p = ["post_id", "url", "caption"]

    BASE = f"INSERT INTO {tablename}({','.join(colnames)}) VALUES "
    BASE_T = f"INSERT INTO {tablename_t}({','.join(colnames_t)}) VALUES "
    BASE_P = f"INSERT INTO {tablename_p}({','.join(colnames_p)}) VALUES "

    dir_pref = "sql/multi_insert/posts/"
    rec_per_file = 200000    

    fileno = 0
    fileno_t = 0
    fileno_p = 0

    values = getValues(csv_file, sep="\t")

    f = open(dir_pref  + str(fileno_t) + sql_file, "w") if split else open(dir_pref + sql_file, "w")
    t = open(dir_pref  + str(fileno_t) + sql_file_t, "w") if split else open(dir_pref + sql_file_t, "w")
    p = open(dir_pref  + str(fileno_p) + sql_file_p, "w") if split else open(dir_pref + sql_file_p, "w")

    f_n = 0    
    t_n = 0
    p_n = 0

    f.write(BASE + "\n")
    t.write(BASE_T + "\n")
    p.write(BASE_P + "\n")

    for i, val in enumerate(values[:-1], start=1):
        # posts table
        f_n += 1
        if split and f_n % rec_per_file == 0:
            f_n = 0
            now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            f.write(f'\t({val[0]}, "{now}");')
            f.close()
            fileno += 1
            f = open(dir_pref  + str(fileno) + sql_file, "w")
            f.write(BASE + "\n")
        if f_n != 1: f.write(",\n")
        now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        f.write(f'\t({val[0]}, "{now}")')

        # photos table
        if val[1]:
            p_n += 1
            if split and p_n % rec_per_file == 0:
                p_n = 0
                p.write(f'\t({i}, "{val[1]}", "{val[2]}");')

                p.close()
                fileno_p += 1
                p = open(dir_pref  + str(fileno_p) + sql_file_p, "w")
                p.write(BASE_P + "\n")
            if p_n != 1: p.write(",\n")
            p.write(f'\t({i}, "{val[1]}", "{val[2]}")')
        
        # texts table
        else:
            t_n += 1
            if split and t_n % rec_per_file == 0:
                t_n = 0
                t.write(f'\t({i}, "{val[2]}");')

                t.close()
                fileno_t += 1
                t = open(dir_pref  + str(fileno_t) + sql_file_t, "w")
                t.write(BASE_T + "\n")
            if t_n != 1: t.write(",\n")
            t.write(f'\t({i}, "{val[2]}")')


    if f_n != 0: f.write(";")
    if t_n != 0: t.write(";")
    if p_n != 0: p.write(";")


def gen(random=True):
    userPosts, postUserCount = posts(random=random)
    print("NO. of Records:",len(userPosts))

    c = 0
    for key,val in userPosts.items():
        if len(val) >= pcount:
            c += 1
    print("Records meeting quota:", c)
    print("MAX ID#:", max(userPosts.keys()))
    savePosts("records/posts.tsv", userPosts)

def sql(split=False):
    # stored procedures
    # postsToSql("records/posts.tsv", "posts.sql", split=False)

    # multi insert
    postsToMI("records/posts.tsv", sql_file="posts.sql", sql_file_t="texts.sql", sql_file_p="photos.sql", split=False)

def populate(scale=1, random=True):
    global SCALE
    SCALE = scale
    gen(random=random)
    sql()
#-------------------------------------------- END POSTS ---------------------------------------#
